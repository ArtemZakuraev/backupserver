package backup

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"backup-server-agent/internal/config"
	"backup-server-agent/internal/logger"
)

type PostgresBackupResult struct {
	Success      bool
	DumpPath     string
	DumpSizeMB   float64
	DumpFilename string
	StoragePath  string
	Error        string
}

// ExecutePostgresBackup выполняет резервное копирование PostgreSQL базы данных
func ExecutePostgresBackup(task config.PostgresTask, conn config.PostgresConnection, serverIP string, log *logger.Logger) (*PostgresBackupResult, error) {
	result := &PostgresBackupResult{}

	// Расшифровываем пароль (в будущем можно добавить шифрование)
	password := conn.Password

	// Формируем имя файла дампа
	timestamp := time.Now().Format("20060102_150405")
	dbNameSafe := strings.ReplaceAll(strings.ReplaceAll(task.Database, "/", "_"), "\\", "_")

	var dumpFilename string
	switch task.BackupFormat {
	case "custom":
		dumpFilename = fmt.Sprintf("%s_%s.dump", dbNameSafe, timestamp)
	case "plain":
		dumpFilename = fmt.Sprintf("%s_%s.sql", dbNameSafe, timestamp)
	case "tar":
		dumpFilename = fmt.Sprintf("%s_%s.tar", dbNameSafe, timestamp)
	default:
		dumpFilename = fmt.Sprintf("%s_%s.sql", dbNameSafe, timestamp)
	}

	// Создаем временную директорию для дампов
	tempDir := "/tmp/postgres_backups"
	if err := os.MkdirAll(tempDir, 0755); err != nil {
		result.Error = fmt.Sprintf("Failed to create temp directory: %v", err)
		return result, fmt.Errorf(result.Error)
	}

	dumpPath := filepath.Join(tempDir, dumpFilename)

	// Формируем команду pg_dump
	cmd := exec.Command(
		"pg_dump",
		fmt.Sprintf("--host=%s", conn.Host),
		fmt.Sprintf("--port=%d", conn.Port),
		fmt.Sprintf("--username=%s", conn.Username),
		fmt.Sprintf("--dbname=%s", task.Database),
		fmt.Sprintf("--format=%s", task.BackupFormat),
		fmt.Sprintf("--file=%s", dumpPath),
	)

	// Добавляем опции в зависимости от формата
	if task.BackupFormat == "custom" {
		cmd.Args = append(cmd.Args, fmt.Sprintf("--compress=%d", task.CompressionLevel))
	} else if task.BackupFormat == "plain" {
		cmd.Args = append(cmd.Args, "--no-owner", "--no-privileges")
	}

	// Опции включения/исключения
	if !task.IncludeSchema && !task.IncludeData {
		// Если оба выключены, включаем оба (по умолчанию)
	} else if !task.IncludeSchema {
		cmd.Args = append(cmd.Args, "--data-only")
	} else if !task.IncludeData {
		cmd.Args = append(cmd.Args, "--schema-only")
	}

	if task.IncludeRoles {
		cmd.Args = append(cmd.Args, "--roles-only")
	}

	if task.IncludeTablespaces {
		cmd.Args = append(cmd.Args, "--tablespaces")
	}

	// Устанавливаем переменную окружения с паролем
	cmd.Env = append(os.Environ(), fmt.Sprintf("PGPASSWORD=%s", password))

	log.Infof("Executing pg_dump for database %s on %s:%d", task.Database, conn.Host, conn.Port)

	// Выполняем pg_dump
	output, err := cmd.CombinedOutput()
	if err != nil {
		errorMsg := string(output)
		if errorMsg == "" {
			errorMsg = err.Error()
		}
		log.Errorf("pg_dump failed: %s", errorMsg)
		result.Error = errorMsg
		return result, fmt.Errorf("pg_dump failed: %s", errorMsg)
	}

	// Проверяем размер файла
	stat, err := os.Stat(dumpPath)
	if err != nil {
		result.Error = fmt.Sprintf("Dump file was not created: %v", err)
		return result, fmt.Errorf(result.Error)
	}

	result.DumpSizeMB = float64(stat.Size()) / (1024 * 1024)
	result.DumpFilename = dumpFilename
	result.DumpPath = dumpPath

	// Загружаем в хранилище
	storagePath, err := uploadPostgresBackupToStorage(task, dumpPath, dbNameSafe, log)
	if err != nil {
		result.Error = fmt.Sprintf("Failed to upload to storage: %v", err)
		// Удаляем локальный файл даже при ошибке загрузки
		os.Remove(dumpPath)
		return result, fmt.Errorf(result.Error)
	}

	result.StoragePath = storagePath
	result.Success = true

	// Удаляем локальный файл после успешной загрузки
	if err := os.Remove(dumpPath); err != nil {
		log.Warnf("Failed to remove local dump file: %v", err)
	} else {
		log.Infof("Local dump file removed: %s", dumpPath)
	}

	return result, nil
}

// RestorePostgresBackup восстанавливает базу данных из резервной копии
func RestorePostgresBackup(task config.PostgresTask, conn config.PostgresConnection, storagePath string, targetDatabase string, log *logger.Logger) (*PostgresBackupResult, error) {
	result := &PostgresBackupResult{}

	// Расшифровываем пароль
	password := conn.Password

	// Определяем целевую БД
	restoreDB := targetDatabase
	if restoreDB == "" {
		restoreDB = task.Database
	}

	// Создаем временную директорию
	tempDir := "/tmp/postgres_backups"
	if err := os.MkdirAll(tempDir, 0755); err != nil {
		result.Error = fmt.Sprintf("Failed to create temp directory: %v", err)
		return result, fmt.Errorf(result.Error)
	}

	// Скачиваем файл из хранилища
	// Извлекаем имя файла из пути хранилища
	filename := filepath.Base(storagePath)
	if filename == "" || filename == "." {
		// Если не удалось извлечь имя, генерируем временное
		filename = fmt.Sprintf("restore_%d.dump", time.Now().Unix())
	}

	localFile := filepath.Join(tempDir, filename)

	// TODO: Реализовать скачивание из хранилища
	// Пока предполагаем, что файл уже доступен локально или нужно реализовать StorageManager
	log.Warnf("Storage download not yet implemented, assuming file is at: %s", storagePath)

	// Определяем формат по расширению
	fileExt := strings.ToLower(filepath.Ext(localFile))
	var restoreCmd string
	if fileExt == ".dump" || fileExt == ".custom" || fileExt == ".tar" {
		restoreCmd = "pg_restore"
	} else {
		restoreCmd = "psql"
	}

	// Формируем команду восстановления
	var cmd *exec.Cmd
	if restoreCmd == "pg_restore" {
		cmd = exec.Command(
			"pg_restore",
			fmt.Sprintf("--host=%s", conn.Host),
			fmt.Sprintf("--port=%d", conn.Port),
			fmt.Sprintf("--username=%s", conn.Username),
			fmt.Sprintf("--dbname=%s", restoreDB),
			"--clean",
			"--if-exists",
			localFile,
		)
	} else {
		// Для plain SQL используем psql
		cmd = exec.Command(
			"psql",
			fmt.Sprintf("--host=%s", conn.Host),
			fmt.Sprintf("--port=%d", conn.Port),
			fmt.Sprintf("--username=%s", conn.Username),
			fmt.Sprintf("--dbname=%s", restoreDB),
			"--file", localFile,
		)
	}

	cmd.Env = append(os.Environ(), fmt.Sprintf("PGPASSWORD=%s", password))

	log.Infof("Restoring database %s from %s", restoreDB, localFile)

	// Выполняем восстановление
	output, err := cmd.CombinedOutput()
	if err != nil {
		errorMsg := string(output)
		if errorMsg == "" {
			errorMsg = err.Error()
		}
		log.Errorf("Restore failed: %s", errorMsg)
		result.Error = errorMsg
		return result, fmt.Errorf("restore failed: %s", errorMsg)
	}

	result.Success = true
	log.Infof("Database %s restored successfully", restoreDB)

	// Удаляем локальный файл
	if err := os.Remove(localFile); err != nil {
		log.Warnf("Failed to remove local restore file: %v", err)
	}

	return result, nil
}

// uploadPostgresBackupToStorage загружает дамп в хранилище
func uploadPostgresBackupToStorage(task config.PostgresTask, dumpPath string, dbNameSafe string, log *logger.Logger) (string, error) {
	// Парсим конфигурацию хранилища из JSON
	// TODO: Реализовать универсальный StorageManager для агента
	// Пока используем только S3 для совместимости

	// Если StorageType не указан или это S3, используем старую логику
	if task.StorageType == "" || task.StorageType == "s3" {
		// Парсим S3 конфигурацию из StorageConfig JSON
		// Это временное решение, нужно реализовать универсальный StorageManager
		log.Warnf("S3 upload from postgres_backup.go not yet fully implemented")
		return "", fmt.Errorf("storage upload not yet implemented for agent")
	}

	// Для других типов хранилищ нужно реализовать соответствующие клиенты
	return "", fmt.Errorf("storage type %s not yet implemented in agent", task.StorageType)
}



